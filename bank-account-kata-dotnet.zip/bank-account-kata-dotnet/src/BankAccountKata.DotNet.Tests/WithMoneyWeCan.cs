namespace BankAccountKata.Dotnet.Tests;

//[Fact(DisplayName = "With Money we can ... ")]
public class WithMoneyWeCan 
{

}
