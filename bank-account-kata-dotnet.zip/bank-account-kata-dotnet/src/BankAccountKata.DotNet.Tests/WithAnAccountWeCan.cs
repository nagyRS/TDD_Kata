using FluentAssertions;
using BankAccountKata.Dotnet;
using System.Security.Principal;

namespace BankAccountKata.Dotnet.Tests;

public class WithAnAccountWeCan 
{

    [Fact]
    public void DepositAnAmountToIncreaseTheBalance() 
    {
        var account = new Account(1);
        account.Deposit(new Money(100m));
        account.GetBalace().Should().Be(100m);
    }

    [Fact]
    public void WithdrawAnAmountToDecTheBalance()
    {
        var account = new Account(1);
        account.Deposit(new Money(100m));
        account.Withdraw(new Money(50m));
        account.GetBalace().Should().Be(50m);
    }

    [Fact]
    public void WhenNotEnoughBalanceShouldNot()
    {
        var account = new Account(1);
        account.Deposit(new Money(100m));
        var sucess = account.Withdraw(new Money(150m));
        sucess.Should().Be(false);
    }

    [Fact]
    public void Transfer()
    {
        var account1 = new Account(1);
        var account2 = new Account(2);

        account1.Deposit(new Money(100m));

        account1.TransferOut(new Money(50m), account2);

        account1.GetBalace().Should().Be(50m);
        account2.GetBalace().Should().Be(50m);
    }

    [Fact]
    public void TransferFailed()
    {
        var account1 = new Account(1);
        var account2 = new Account(2);

        account1.Deposit(new Money(100m));

        var success = account1.TransferOut(new Money(150m), account2);
        success.Should().Be(false);
    }

    [Fact]
    public void PrintBalance()
    {
        var account = new Account(1);

        account.Deposit(new Money(100m));
        var print = "Balance on 18/09/2024 is 100";
        print.Should().Be(account.PrintBalance());
    }
}
