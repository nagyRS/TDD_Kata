namespace BankAccountKata.Dotnet;

/**
 * Immutable class to represent Money as a concept.
 * This class should have no accessor methods.
 */
public class AccountBalance
{
    private decimal _amount;

    public AccountBalance(decimal amount)
    {
        _amount = amount;
    }

    public void Add(decimal amount)
    {
        _amount = _amount + amount;
    }

    public void Remove(decimal amount)
    {
        _amount = _amount - amount;
    }

    public decimal GetAmount()
    {
        return _amount;
    }
}

public struct Money
{ 
    private readonly decimal _value;

    public Money(decimal value)
    {
        _value = value; 
    }

    public static Money operator + (Money a, Money b) =>  new Money(a._value + b._value);

    public static Money operator - (Money a, Money b) {
        if (a._value < b._value)
            throw new Exception();

        new Money(a._value - b._value);
            
            }

}
