﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountKata.Dotnet
{
    public enum TransactionType
    {
        Deposit,
        Withdraw,
        TransferIn,
        TransferOut,
    }
}
