using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;

namespace BankAccountKata.Dotnet;

public class Account
{

    public static GetAccount()
    { 
        
    
    }

    public Account(int accountId)
    {
        Transactions = new List<Transaction>();
        AccountId = accountId;
        Balance = new Money(0);
    }

    public int AccountId { get; private set; }
    private List<Transaction> Transactions { get; set; }

    private Money Balance { get; set; }

    public bool Deposit(Money amount)
    {
        Transactions.Add(new Transaction
        {
            Money = amount,
            TransactionType = TransactionType.Deposit
        });

        Balance.Add(amount.GetAmount());

        return true;
    }

    public bool Withdraw(Money amount)
    {
        if (!HasBalance(Balance.GetAmount(), amount.GetAmount()))
        {
            return false;
        }

        Transactions.Add(new Transaction
        {
            Money = amount,
            TransactionType = TransactionType.Withdraw
        });

        Balance.Remove(amount.GetAmount());

        return true;
    }

    public bool TransferOut(Money amount, Account account)
    {
        if (!HasBalance(Balance.GetAmount(), amount.GetAmount()))
        {
            return false;
        }

        Transactions.Add(new Transaction
        {
            Money = amount,
            TransactionType = TransactionType.TransferOut,
            AccountId = account.AccountId
        });

        Balance.Remove(amount.GetAmount());

        account.TransferIn(amount, this.AccountId);

        return true;
    }

    public bool TransferIn(Money amount, int accountId)
    {

        Transactions.Add(new Transaction
        {
            Money = amount,
            TransactionType = TransactionType.TransferIn,
            AccountId = accountId
        });

        Balance.Add(amount.GetAmount());

        return true;
    }

    public decimal GetBalace()
    {
        return Balance.GetAmount();
    }
    public string PrintBalance()
    {
        return $"Balance on {DateTime.Now.ToString("d")} is {GetBalace()}";
    }

    private bool HasBalance(decimal balance, decimal amount)
    {
        return balance >= amount;
    }

    public List<Transaction> GetStatement()
    {
        var tran = new List<Transaction>();
        Transactions.CopyTo(tran.ToArray(), 0);
        return tran;
    }

}
